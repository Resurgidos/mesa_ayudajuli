package main;
import Interfaces.MENÚ;

public class Main {

    public static void main(String[] args) {
       
       MENÚ menu = new MENÚ();
       menu.setVisible(true);
    }



}
